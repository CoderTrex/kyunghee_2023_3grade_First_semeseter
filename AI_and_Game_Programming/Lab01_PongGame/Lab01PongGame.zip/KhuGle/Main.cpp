#include "KhuGleWin.h"
#include <io.h>
#include <cmath>
#include <cstdio>
#include <string>
#include <cstdlib>
#include <iostream>
#include <string.h>
#include <crtdbg.h>

#pragma warning(disable:4996)
#define _CRTDBG_MAP_ALLOC

#ifdef _DEBUG
#ifndef DBG_NEW
#define DBG_NEW new ( _NORMAL_BLOCK , __FILE__ , __LINE__ )
#define new DBG_NEW
#endif
#endif  // _DEBUG

int level = 0;
class CCollision : public CKhuGleWin
{
public:
	CKhuGleLayer *m_pGameLayer;
	CKhuGleLayer* m_pEndLayer;

	std::vector<CKhuGleSprite*> m_BrickContainer;
	
	CKhuGleSprite *Circle1;

	CKhuGleSprite* OutLine1;
	CKhuGleSprite* OutLine2;
	CKhuGleSprite* OutLine3;
	CKhuGleSprite* OutLine4;

	CKhuGleSprite* Paddle1;
	CKhuGleSprite* Paddle2;

	CKhuGleSprite* Brick1[50];
	CKhuGleSprite* Brick2[50];

	bool		m_pause = true;
	int			score = 0;
	int			level = 0;
	int			life = 3;
	int			brick_num = 0;

	CCollision(int nW, int nH);
	void Update();
	void EndGame();

	CKgPoint m_LButtonStart, m_LButtonEnd;
	int m_nLButtonStatus;
};

CCollision::CCollision(int nW, int nH) 
	: CKhuGleWin(nW, nH) 
	, m_pEndLayer()
{
	m_nLButtonStatus = 0;

	m_Gravity = CKgVector2D(0., 98.);
	m_AirResistance = CKgVector2D(0.1, 0.1);
	m_pScene = new CKhuGleScene(640, 480, KG_COLOR_24_RGB(100, 100, 150));
	
	m_pGameLayer = new CKhuGleLayer(600, 420, KG_COLOR_24_RGB(150, 150, 200), CKgPoint(20, 30));
	m_pScene->AddChild(m_pGameLayer);

	Circle1 = new CKhuGleSprite(GP_STYPE_ELLIPSE, GP_CTYPE_DYNAMIC, CKgLine(CKgPoint(360, 360), CKgPoint(380, 380)), KG_COLOR_24_RGB(255, 0, 0), true, 100);

	Paddle1 = new CKhuGleSprite(GP_STYPE_LINE, GP_CTYPE_DYNAMIC, CKgLine(CKgPoint(300, 400), CKgPoint(400, 400)), KG_COLOR_24_RGB(0, 255, 0), false, 30);
	Paddle2 = new CKhuGleSprite(GP_STYPE_LINE, GP_CTYPE_DYNAMIC, CKgLine(CKgPoint(350, 385), CKgPoint(350, 415)), KG_COLOR_24_RGB(0, 255, 0), true, 100);
	
	OutLine1 = new CKhuGleSprite(GP_STYPE_LINE, GP_CTYPE_STATIC, CKgLine(CKgPoint(-1, 0),   CKgPoint(600, 0)  ), KG_COLOR_24_RGB(255, 255, 0), false, 0);;
	OutLine2 = new CKhuGleSprite(GP_STYPE_LINE, GP_CTYPE_STATIC, CKgLine(CKgPoint(600, 0), CKgPoint(600, 425)), KG_COLOR_24_RGB(255, 255, 0), false, 0);
	OutLine3 = new CKhuGleSprite(GP_STYPE_LINE, GP_CTYPE_STATIC, CKgLine(CKgPoint(-1, 425), CKgPoint(600, 425)), KG_COLOR_24_RGB(255, 0, 0), false, 10);
	OutLine4 = new CKhuGleSprite(GP_STYPE_LINE, GP_CTYPE_STATIC, CKgLine(CKgPoint(-1, 0),   CKgPoint(-1, 425)  ), KG_COLOR_24_RGB(255, 255, 0), true, 0);
	
	m_pGameLayer->AddChild(Circle1);
	m_pGameLayer->AddChild(Paddle1);
	m_pGameLayer->AddChild(Paddle2);
	m_pGameLayer->AddChild(OutLine1);
	m_pGameLayer->AddChild(OutLine2);
	m_pGameLayer->AddChild(OutLine3);
	m_pGameLayer->AddChild(OutLine4);
	Circle1->m_Velocity = CKgVector2D(-200, 200);
	
	// ���� ����
	brick_num = 0;
	for (int column = 0; column < 4; column++) {
		for (int row = 0; row < 6; row++) {
			Brick1[brick_num] = new CKhuGleSprite(GP_STYPE_LINE, GP_CTYPE_KINEMATIC, CKgLine(CKgPoint(100*row,	  40*column+20), CKgPoint(100*(row+1), 40*column+20)), KG_COLOR_24_RGB(0, 255, 255), false, 40);
			Brick2[brick_num] = new CKhuGleSprite(GP_STYPE_LINE, GP_CTYPE_KINEMATIC, CKgLine(CKgPoint(100*row+50,  40*column   ), CKgPoint(100*row+50  , 40*column+40)), KG_COLOR_24_RGB(0, 255, 255), false, 100);
			m_BrickContainer.push_back(Brick1[brick_num]);
			m_BrickContainer.push_back(Brick2[brick_num]);
			m_pGameLayer->AddChild(Brick1[brick_num]);
			m_pGameLayer->AddChild(Brick2[brick_num]);
			brick_num++;
		}
	}
}

void CCollision::EndGame()
{
	exit(EXIT_SUCCESS);
}

void CCollision::Update()
{
	/* Ű���� ��Ʈ�ѷ�*/
	if (m_bKeyPressed[VK_LEFT])
	{
		if (Paddle1->m_Center.x >= 55 && Paddle1->m_Center.x <= 545)
		{
			Paddle1->MoveBy(-2, 0);
			Paddle2->MoveBy(-2, 0);
		}
		else if (Paddle1->m_Center.x >= 545)
		{
			Paddle1->MoveBy(-2, 0);
			Paddle2->MoveBy(-2, 0);
		}
	}
	if (m_bKeyPressed[VK_RIGHT])
	{
		if (Paddle1->m_Center.x > 55 && Paddle1->m_Center.x < 545)
		{
			Paddle1->MoveBy(2, 0);
			Paddle2->MoveBy(2, 0);
		}
		else if (Paddle1->m_Center.x <= 55)
		{
			Paddle1->MoveBy(+2, 0);
			Paddle2->MoveBy(+2, 0);
		}
	}
	/* ESC�� ���� ���� */
	if (m_bKeyPressed[VK_ESCAPE])
	{
		EndGame();
	}

	for(auto &Layer : m_pScene->m_Children)
	{
		for(auto &Sprite : Layer->m_Children)
		{
			CKhuGleSprite *LineRect = (CKhuGleSprite *)Sprite; 
			LineRect->m_bCollided = false;

			if (LineRect->m_nType == GP_STYPE_RECT) continue; 
			if (LineRect->m_nCollisionType != GP_CTYPE_DYNAMIC) continue; 
			if (LineRect->m_nType == GP_STYPE_ELLIPSE)
			{
				LineRect->MoveBy(LineRect->m_Velocity.x * m_ElapsedTime, LineRect->m_Velocity.y * m_ElapsedTime);
				if (LineRect->m_Center.x < 0) 
					LineRect->MoveTo(m_nW + LineRect->m_Center.x, LineRect->m_Center.y);
				if (LineRect->m_Center.x > m_nW) 
					LineRect->MoveTo(LineRect->m_Center.x - m_nW, LineRect->m_Center.y);
				if (LineRect->m_Center.y < 0) 
					LineRect->MoveTo(LineRect->m_Center.x, m_nH + LineRect->m_Center.y);
				if (LineRect->m_Center.y > m_nH) 
					LineRect->MoveTo(LineRect->m_Center.x, LineRect->m_Center.y - m_nH);
			}

			if(CKgVector2D::abs(LineRect->m_Velocity) < 0.01)
				LineRect->m_Velocity = CKgVector2D(0, 0);
		}

		std::vector<std::pair<CKhuGleSprite*, CKhuGleSprite*>> CollisionPairs;
		
		for(auto &SpriteA : Layer->m_Children)
		{
			CKhuGleSprite* Ball = static_cast<CKhuGleSprite*>(SpriteA);
			if (Ball->m_nType != GP_STYPE_ELLIPSE)
				continue;

			for(auto &SpriteB : Layer->m_Children)
			{
				CKhuGleSprite* Target = static_cast<CKhuGleSprite*>(SpriteB);

				if (Ball == Target)
					continue; 

				else if (static_cast<CKhuGleSprite*>(Target)->m_nType == GP_STYPE_LINE) 
				{				
					/*�����͸� ���ϰ� �̸� ����ȭ�� -> ���߿� �������� ����ϱ� ���ؼ���*/
					/*�߰��� �ش� ���� ������ ũ�⸦ ����*/
					CKgVector2D LineVecotr = {static_cast<double>(Target->m_lnLine.End.X - Target->m_lnLine.Start.X), static_cast<double>(Target->m_lnLine.End.Y - Target->m_lnLine.Start.Y)};
					LineVecotr.Normalize();
					double LineVecotrSize = sqrt(pow(static_cast<double>(Target->m_lnLine.End.X - Target->m_lnLine.Start.X), 2) + pow(static_cast<double>(Target->m_lnLine.End.Y - Target->m_lnLine.Start.Y), 2));
					
					/*���� ���� ���Ϳ� ũ�⸦ ����*/
					CKgVector2D Line2BallVector = Ball->m_Center - Target->m_lnLine.Start;
					
					/*������ ���͸� ���ϰ� ũ�⸦ ����*/
					CKgVector2D Projection2Line = Line2BallVector.Dot(LineVecotr) * LineVecotr;
					double Projection2LineSize = Line2BallVector.Dot(LineVecotr);
					
					/*���� ������ ũ�⸦ ����*/ 
					double NormalSize = sqrt(pow(CKgVector2D::abs(Line2BallVector), 2) - pow(Projection2LineSize, 2));
					if (Ball->m_Radius >= NormalSize - Target->m_nWidth/2)
					{
						/*�� ������ ���� �ᱹ ���� �̵����� ũ��� ����*/
						CKgVector2D ReflectionVector = Projection2Line + Line2BallVector;
						/*�浹 ���� Ȯ�� ����(������ ���� ����)*/
						if (Line2BallVector.Dot(LineVecotr) >= 0 && Line2BallVector.Dot(LineVecotr) <= LineVecotrSize) 
						{
							CollisionPairs.push_back({Ball, Target});
							/*�浹�� ũ�⸦ ��������  �浹�ϴ� ũ��� �������־ �浹���� �����*/
							double impact = NormalSize - Target->m_nWidth/2;
							Ball->MoveBy(ReflectionVector.x * impact / CKgVector2D::abs(ReflectionVector), ReflectionVector.y * impact / CKgVector2D::abs(ReflectionVector));
						}
					}
				}
			}
		}

		for(auto &Pair : CollisionPairs)
		{
			/*������ �浹*/
			if (Pair.second->m_nType == GP_STYPE_LINE)
			{
				CKhuGleSprite* Ball = Pair.first;
				CKhuGleSprite* Line = Pair.second;

				/*���� ���͸� ���ϱ� ���� ���ϴ� �浹�� �� ����*/
				CKgVector2D LineVector = {static_cast<double>(Line->m_lnLine.Start.X - Line->m_lnLine.End.X), static_cast<double>(Line->m_lnLine.Start.Y - Line->m_lnLine.End.Y)};
				LineVector.Normalize();
				/*���� ����*/
				CKgVector2D normal = { LineVector.y, -LineVector.x };
				/*���� ���͸� �������� �ݻ簢 ���ϴ� ���� ����*/
				Ball->m_Velocity = Ball->m_Velocity - 2 * (Ball->m_Velocity.Dot(normal)) * normal;

				/*�׳� �Ź� �Ȱ��� Ƣ��� ��� �����ϱ� �ణ�� ������ �� �߰��ؼ� ������ ���� �ٸ� ������ �� �� �ְ� ��.*/
				double randX = ((double)rand() / RAND_MAX) * 0.2 - 0.1; // Random value between -0.1 and 0.1
				double randY = ((double)rand() / RAND_MAX) * 0.2 - 0.1; // Random value between -0.1 and 0.1

				CKgVector2D randomVector = { randX, randY };
				Ball->m_Velocity += randomVector;
				if (Line == OutLine3)
				{
					life -= 1;
					if (life <= 0)
					{
						life = 0;
						Ball->m_Velocity.x = 0;
						Ball->m_Velocity.y = 0;
					}
				}
				if (Pair.second->m_nCollisionType == GP_CTYPE_KINEMATIC)
				{
					for (auto& line : m_BrickContainer)
					{
						if (Line->m_Center.x == line->m_Center.x && Line->m_Center.y == line->m_Center.y)
							line->m_nType = GP_STYPE_DESTORY;
					}
					Line->m_nType = GP_STYPE_DESTORY; 
					score += 10;
				}
			}
		}
	}

	m_pScene->Render();
	DrawSceneTextPos("Lab 01 Pong Game", CKgPoint(0, 0));
	DrawSceneTextPos("Life: ", CKgPoint(250, 0));
	DrawSceneTextPos("Score: ", CKgPoint(400, 0));
	std::string score_string = std::to_string(score);
	std::string life_string = std::to_string(life);
	DrawSceneTextPos(life_string.c_str(), CKgPoint(320, 0));
	DrawSceneTextPos(score_string.c_str(), CKgPoint(460, 0));

	/*����� 0�� �Ǹ� ���� ����*/
	if (life <= 0)
		DrawSceneTextPos("Game Over, Press ESC to exit", CKgPoint(180, 270));
	
	/*���ھ 240�̸� ��� ������ ���ٴ� ����->���� ������.*/
	if (score >= 240)
	{
		DrawSceneTextPos("Game Clear, Press ESC to exit", CKgPoint(180, 270));
		//m_pScene->m_Children
		for (auto& Layer : m_pScene->m_Children) {
			for (auto& Sprite : Layer->m_Children) {
				CKhuGleSprite* Ball = static_cast<CKhuGleSprite*>(Sprite);
				if (Ball->m_nType == GP_STYPE_ELLIPSE)
					Ball->m_Velocity = CKgVector2D(0, 0);
			}
		}
	}
	CKhuGleWin::Update();
}

int main()
{
	CCollision* pCollision = new CCollision(640, 480);
	KhuGleWinInit(pCollision);
	return 0;
}