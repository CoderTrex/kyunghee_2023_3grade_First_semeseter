﻿//
//	Dept. Software Convergence, Kyung Hee University
//	Prof. Daeho Lee, nize@khu.ac.kr
//
// 외부 KHU라이브러리
#include "KhuGleWin.h"
#include "KhuGleSignal.h"
#include "KhuGleBase.h"
#include <iostream>

#pragma warning(disable:4996)

#define _CRTDBG_MAP_ALLOC
// 내장 라이브러리
#include <cstdlib>
#include <crtdbg.h>
#include <string.h>
#include <string>
#include <iomanip>

#ifdef _DEBUG
#ifndef DBG_NEW
#define DBG_NEW new ( _NORMAL_BLOCK , __FILE__ , __LINE__ )
#define new DBG_NEW
#endif
#endif  // _DEBUG

// Z를 누르면 실행됩니다.

// pdf에 나오는 테이블
double QuantizationTable[8][8] = {
{16, 11, 10, 16, 24, 40, 51, 61},
{12, 12, 14, 19, 26, 58, 60, 55},
{14, 13, 16, 24, 40, 57, 69, 56},
{14, 17, 22, 29, 51, 87, 80, 62},
{18, 22, 37, 56, 68, 109, 103, 77},
{24, 35, 55, 64, 81, 104, 113, 92},
{49, 64, 78, 87, 103, 121, 120, 101},
{72, 92, 95, 98, 112, 100, 103, 99}
};

double QuantizationTable_2[8][8] = {
{17, 18, 24, 47, 99, 99, 99, 99},
{18, 21, 26, 66, 99, 99, 99, 99},
{24, 26, 56, 99, 99, 99, 99, 99},
{47, 66, 99, 99, 99, 99, 99, 99},
{99, 99, 99, 99, 99, 99, 99, 99},
{99, 99, 99, 99, 99, 99, 99, 99},
{99, 99, 99, 99, 99, 99, 99, 99},
{99, 99, 99, 99, 99, 99, 99, 99}
};

class CKhuGleImageLayer : public CKhuGleLayer {
public:
	//            원본     최종 결과물 
	CKhuGleSignal m_Image, m_ImageOut;

	CKhuGleImageLayer(int nW, int nH, KgColor24 bgColor, CKgPoint ptPos = CKgPoint(0, 0))
		: CKhuGleLayer(nW, nH, bgColor, ptPos) {}
	void DrawImage();
};

// 이미지 생성 함수
void CKhuGleImageLayer::DrawImage() {
	int OffsetX, OffsetY;

	for (int y = 0; y < m_nH; y++)
		for (int x = 0; x < m_nW; x++)
		{
			m_ImageBgR[y][x] = KgGetRed(m_bgColor);
			m_ImageBgG[y][x] = KgGetGreen(m_bgColor);
			m_ImageBgB[y][x] = KgGetBlue(m_bgColor);
		}

	// 원본 이미지 출력
	if (m_Image.m_Red && m_Image.m_Green && m_Image.m_Blue)
	{
		for (int y = 0; y < m_Image.m_nH && y < m_nH; ++y)
			for (int x = 0; x < m_Image.m_nW && x < m_nW; ++x)
			{
				m_ImageBgR[y + 10][x] = m_Image.m_Red[y][x];
				m_ImageBgG[y + 10 ][x] = m_Image.m_Green[y][x];
				m_ImageBgB[y + 10][x] = m_Image.m_Blue[y][x];
			}
	}
	
	// 결과값 이미지 출력
	if (m_ImageOut.m_Red && m_ImageOut.m_Green && m_ImageOut.m_Blue)
	{
		OffsetX = 600;
		OffsetY = 10;
		for (int y = 0; y < m_ImageOut.m_nH && y + OffsetY < m_nH; ++y)
			for (int x = 0; x < m_ImageOut.m_nW && x + OffsetX < m_nW; ++x)
			{
				m_ImageBgR[y + OffsetY][x + OffsetX] = m_ImageOut.m_Red[y][x];
				m_ImageBgG[y + OffsetY][x + OffsetX] = m_ImageOut.m_Green[y][x];
				m_ImageBgB[y + OffsetY][x + OffsetX] = m_ImageOut.m_Blue[y][x];
			}
	}
}

class CImageProcessing : public CKhuGleWin {
public:
	CKhuGleImageLayer *m_pImageLayer;

	CImageProcessing(int nW, int nH, char *ImagePath);	
	void Update();
};

CImageProcessing::CImageProcessing(int nW, int nH, char *ImagePath) 
	: CKhuGleWin(nW, nH) {

	m_pScene = new CKhuGleScene(1280, 800, KG_COLOR_24_RGB(100, 100, 150));

	m_pImageLayer = new CKhuGleImageLayer(1280, 800, KG_COLOR_24_RGB(150, 150, 200), CKgPoint(20, 30));
	m_pImageLayer->m_Image.ReadBmp(ImagePath);
	m_pImageLayer->m_ImageOut.ReadBmp(ImagePath);
	m_pScene->AddChild(m_pImageLayer);
}

void CImageProcessing::Update()
{	
	bool zip = m_bKeyPressed['Z'];
	
	if (zip)
	{
		// 나중에 이미지 압축과 복원에 사용할 변수
		int		 Y_Zero = 0, Cb_Zero = 0, Cr_Zero = 0;
		int		 Y_MAX = INT_MIN, Cb_MAX = INT_MIN, Cr_MAX = INT_MIN;
		int		 Y_MIN = INT_MAX, Cb_MIN = INT_MAX, Cr_MIN = INT_MAX;

		// 입력된 RGB값, YCrCb값 init YCbCr값은 2x2 공간으로 묶을 것이기 때문에 /2를 해서 공간을 4배 줄인다.
		double** InputR = dmatrix(m_pImageLayer->m_Image.m_nH, m_pImageLayer->m_Image.m_nW);
		double** InputG = dmatrix(m_pImageLayer->m_Image.m_nH, m_pImageLayer->m_Image.m_nW);
		double** InputB = dmatrix(m_pImageLayer->m_Image.m_nH, m_pImageLayer->m_Image.m_nW);

		double** InputY = dmatrix(m_pImageLayer->m_Image.m_nH, m_pImageLayer->m_Image.m_nW);
		double** InputCb = dmatrix(m_pImageLayer->m_Image.m_nH/2, m_pImageLayer->m_Image.m_nW/2);
		double** InputCr = dmatrix(m_pImageLayer->m_Image.m_nH/2, m_pImageLayer->m_Image.m_nW/2);
		
		double** DCT_Y = dmatrix(m_pImageLayer->m_Image.m_nH, m_pImageLayer->m_Image.m_nW);
		double** DCT_Cb = dmatrix(m_pImageLayer->m_Image.m_nH / 2, m_pImageLayer->m_Image.m_nW / 2);
		double** DCT_Cr = dmatrix(m_pImageLayer->m_Image.m_nH / 2, m_pImageLayer->m_Image.m_nW / 2);

		double** Quan_Y = dmatrix(m_pImageLayer->m_Image.m_nH, m_pImageLayer->m_Image.m_nW);
		double** Quan_Cb = dmatrix(m_pImageLayer->m_Image.m_nH / 2, m_pImageLayer->m_Image.m_nW / 2);
		double** Quan_Cr = dmatrix(m_pImageLayer->m_Image.m_nH / 2, m_pImageLayer->m_Image.m_nW / 2);

		double** OutR = dmatrix(m_pImageLayer->m_Image.m_nH, m_pImageLayer->m_Image.m_nW);
		double** OutG = dmatrix(m_pImageLayer->m_Image.m_nH, m_pImageLayer->m_Image.m_nW);
		double** OutB = dmatrix(m_pImageLayer->m_Image.m_nH, m_pImageLayer->m_Image.m_nW);
		
		// 1. RGB 값 matrix init
		for (int y = 0; y < m_pImageLayer->m_Image.m_nH; ++y)
			for (int x = 0; x < m_pImageLayer->m_Image.m_nW; ++x){
				InputR[y][x] = m_pImageLayer->m_Image.m_Red[y][x];
				InputG[y][x] = m_pImageLayer->m_Image.m_Green[y][x];
				InputB[y][x] = m_pImageLayer->m_Image.m_Blue[y][x];
			}

		// 입력 영상이 WXH이면, Y는 동일하고 CbCr은 (W/2)X(H/2)﻿
		// 2. Y값 Cr값 Cb값 matrix init
		// Y = R*0.299+G*0.587+B*0.114
		for (int y = 0; y < m_pImageLayer->m_Image.m_nH; ++y)
			for (int x = 0; x < m_pImageLayer->m_Image.m_nW; ++x)
			{
				InputY[y][x] = InputR[y][x] * 0.299 + InputG[y][x] * 0.587 + InputB[y][x] * 0.144;

				// 짝수값만 clamp해서 2x2 값으로 설정함.
				if (y % 2 == 0 && x % 2 == 0)
				{
					InputCb[y / 2][x / 2] = (- 0.16874) * InputR[y][x] + (-0.33126) * InputG[y][x] + 0.5 * InputB[y][x];
					InputCr[y / 2][x / 2] = 0.5 * InputR[y][x] + (- 0.41869) * InputG[y][x] + (- 0.08131)* InputB[y][x];
				}
			}

		// block DCT에서 block 크기를 8X8﻿
		// 3. DCT 작업 -> 8X8 block으로 만들기
		// void DCT2D(double **Input, double **Output, int nW, int nH, int nBlockSize)
		DCT2D(InputY, DCT_Y, m_pImageLayer->m_Image.m_nW, m_pImageLayer->m_Image.m_nH, 8);
		DCT2D(InputCb, DCT_Cb, m_pImageLayer->m_Image.m_nW / 2, m_pImageLayer->m_Image.m_nH / 2, 8);
		DCT2D(InputCr, DCT_Cr, m_pImageLayer->m_Image.m_nW / 2, m_pImageLayer->m_Image.m_nH / 2, 8);
	
		// Quantization후에 각 채널별(Y, Cb, Cr) 
		// 1) 0의 개수, 2) 히스토그램 계산, 3) entropy 계산
		// 4. Quantization 설정
		for (int y = 0; y < m_pImageLayer->m_ImageOut.m_nH; ++y) {
			for (int x = 0; x < m_pImageLayer->m_ImageOut.m_nW; ++x)
			{
				// 해당 과정에서 데이터의 손실이 발생하는데 복구해도 해당과정에서 사라진 정보에 의해 완벽하게 복원될 수 없음
				Quan_Y[y][x] = round(DCT_Y[y][x] / QuantizationTable[y % 8][x % 8]);

				// Zero값 count 및 MAX 값과 MIN값을 찾아서 나중에 범위를 통해 이미지 압축에 활용 
				if (Quan_Y[y][x] == 0)
					Y_Zero++;
				if (Quan_Y[y][x] > Y_MAX)
					Y_MAX = Quan_Y[y][x];
				if (Quan_Y[y][x] < Y_MIN)
					Y_MIN = Quan_Y[y][x];
				
				// 2X2 배열로 만든 것에 대해서 clamp
				if (x % 2 == 0 && y % 2 == 0) {
					Quan_Cb[y / 2][x / 2] = round(DCT_Cb[y / 2][x / 2] / QuantizationTable_2[y / 2 % 8][x / 2 % 8]);
					Quan_Cr[y / 2][x / 2] = round(DCT_Cr[y / 2][x / 2] / QuantizationTable_2[y / 2 % 8][x / 2 % 8]);
					
					if (Quan_Cb[y / 2][x / 2] == 0)
						Cb_Zero++;
					if (Quan_Cb[y / 2][x / 2] > Cb_MAX)
						Cb_MAX = Quan_Cb[y / 2][x / 2];
					if (Quan_Cb[y / 2][x / 2] < Cb_MIN)
						Cb_MIN = Quan_Cb[y / 2][x / 2];

					if (Quan_Cr[y / 2][x / 2] == 0)
						Cr_Zero++;
					if (Quan_Cr[y / 2][x / 2] > Cr_MAX)
						Cr_MAX = Quan_Cr[y / 2][x / 2];
					if (Quan_Cr[y / 2][x / 2] < Cr_MIN)
						Cr_MIN = Quan_Cr[y / 2][x / 2];
				}
			}
		}

		// 엔트로피 계산 세팅
		double delta;
		double entropy = 0;

		// 데이터 구조 초기화
		int* ArrayY = (int*)calloc(Y_MAX - Y_MIN + 1, sizeof(int));
		int* ArrayCb = (int*)calloc(Cb_MAX - Cb_MIN + 1, sizeof(int));
		int* ArrayCr = (int*)calloc(Cr_MAX - Cr_MIN + 1, sizeof(int));

		// YCrCb에 대해서 데이터 집합 생성
		for (int y = 0; y < m_pImageLayer->m_ImageOut.m_nH; ++y) {
			for (int x = 0; x < m_pImageLayer->m_ImageOut.m_nW; ++x)
			{
				ArrayY[int(Quan_Y[y][x]) - Y_MIN] += 1;

				if (y % 2 == 0 && x % 2 == 0) {
					ArrayCb[int(Quan_Cb[y / 2][x / 2]) - Cb_MIN] += 1;
					ArrayCr[int(Quan_Cr[y / 2][x / 2]) - Cr_MIN] += 1;
				}
			}
		}

		std::cout << " 채널별(Y, Cb, Cr) 0의 개수\n";
		std::cout << "Y: " << Y_Zero << " Cb: " << Cb_Zero << " Cr: " << Cr_Zero << "\n";


		// 5. Y히스토그램 생성		
		std::cout << "Y 히스토그램 \n";
		for (int i = 0; i < Y_MAX - Y_MIN + 1; i++) {
			
			std::string name_number = std::to_string(i + Y_MIN);
			std::string name_number2 = std::to_string(ArrayY[i]);
			std::cout << "number: " << name_number << " count: "<< name_number2 << "\n";
			
			// 히스토그램 출력
			int histogram_number = ArrayY[i] / 10;
			for (int k = 0; k < histogram_number; k++)
				std::cout << "|";
			std::cout << '\n';
			
			// 엔트로피 계산
			if (ArrayY[i] != 0) {
				delta = ArrayY[i] / double(m_pImageLayer->m_ImageOut.m_nH * m_pImageLayer->m_ImageOut.m_nW);
				entropy += (delta * log2(delta));
			}
		}
		std::cout << "\n";

		// Y값과 같아서 설명 생략
		std::cout << "Cb의 히스토그램 \n";
		for (int i = 0; i < Cb_MAX - Cb_MIN + 1; i++) {
			std::string name_number = std::to_string(i + Cb_MIN);
			std::string name_number2 = std::to_string(ArrayCb[i]);
			int histogram_number = ArrayCb[i] / 10;
			
			std::cout << "number: " << name_number << " count: " << name_number2 << "\n";

			for (int k = 0; k < histogram_number; k++)
				std::cout << "|";

			std::cout << '\n';

			if (ArrayCb[i] != 0) {
				delta = ArrayCb[i] / double(m_pImageLayer->m_ImageOut.m_nH / 2 * m_pImageLayer->m_ImageOut.m_nW / 2);
				entropy += (delta * log2(delta));
			}
		}
		std::cout << "\n";

		// Y값과 같아서 생략
		std::cout << "Cr의 히스토그램 \n"; 
		for (int i = 0; i < Cr_MAX - Cr_MIN + 1; i++) {
			std::string name_number = std::to_string(i + Cr_MIN);
			std::string name_number2 = std::to_string(ArrayCr[i]);
			int histogram_number = ArrayCr[i] / 10;

			std::cout << "number: " << name_number << " count: " << name_number2 << "\n";
			for (int k = 0; k < histogram_number; k++)
				std::cout << "|";
			std::cout << '\n';
			
			if (ArrayCr[i] != 0) {
				delta = ArrayCr[i] / double(m_pImageLayer->m_ImageOut.m_nH / 2 * m_pImageLayer->m_ImageOut.m_nW / 2);
				entropy += (delta * log2(delta));
			}
		}
		std::cout << "\n";


		// 6. entropy 출력
		entropy *= -1;
		std::cout << "Entropy : " << entropy << "\n";
		
		delete[] ArrayY;
		delete[] ArrayCb;
		delete[] ArrayCr;


		// 원래 이미지 복원 7~11
 
		// 7. Quantization된 정보 다시 원상복구
		for (int y = 0; y < m_pImageLayer->m_ImageOut.m_nH; ++y) {
			for (int x = 0; x < m_pImageLayer->m_ImageOut.m_nW; ++x)
			{
				DCT_Y[y][x] = Quan_Y[y][x] * QuantizationTable[y % 8][x % 8];

				if (y % 2 == 0 && x % 2 == 0) {
					DCT_Cb[y / 2][x / 2] = Quan_Cb[y / 2][x / 2] * QuantizationTable_2[y / 2 % 8][x / 2 % 8];
					DCT_Cr[y / 2][x / 2] = Quan_Cr[y / 2][x / 2] * QuantizationTable_2[y / 2 % 8][x / 2 % 8];
				}
			}
		}

		// 8. IDCT2D 역변환
		IDCT2D(DCT_Y, InputY, m_pImageLayer->m_Image.m_nW, m_pImageLayer->m_Image.m_nH, 8);
		IDCT2D(DCT_Cb, InputCb, m_pImageLayer->m_Image.m_nW / 2, m_pImageLayer->m_Image.m_nH / 2, 8);
		IDCT2D(DCT_Cr, InputCr, m_pImageLayer->m_Image.m_nW / 2, m_pImageLayer->m_Image.m_nH / 2, 8);

		// 9. YCbCr을 RGB로 변환함
		for (int y = 0; y < m_pImageLayer->m_ImageOut.m_nH; ++y) {
			for (int x = 0; x < m_pImageLayer->m_ImageOut.m_nW; ++x)
			{
				InputR[y][x] = InputY[y][x] + InputCr[y/2][x/2] * 1.40200;
				InputG[y][x] = InputY[y][x] + InputCb[y/2][x/2] * -0.34414 + InputCr[y/2][x/2] * -0.71414;
				InputB[y][x] = InputY[y][x] + InputCb[y/2][x/2] * 1.77200;
			}
		}


		// 10. 이미지 복원 결과값, 전체 수정값 다시 출력
		for (int y = 0; y < m_pImageLayer->m_ImageOut.m_nH; ++y)
			for (int x = 0; x < m_pImageLayer->m_ImageOut.m_nW; ++x)
			{

				if (InputR[y][x] <= 255 && InputR[y][x] >= 0)
					m_pImageLayer->m_ImageOut.m_Red[y][x] = InputR[y][x];
				else if (InputR[y][x] < 0)
					m_pImageLayer->m_ImageOut.m_Red[y][x] = 0;
				else
					m_pImageLayer->m_ImageOut.m_Red[y][x] = 255;
				
				if (InputG[y][x] <= 255 && InputG[y][x] >= 0)
					m_pImageLayer->m_ImageOut.m_Green[y][x] = InputG[y][x];
				else if (InputG[y][x] < 0)
					m_pImageLayer->m_ImageOut.m_Green[y][x] = 0;
				else
					m_pImageLayer->m_ImageOut.m_Green[y][x] = 255;

				if (InputB[y][x] <= 255 && InputB[y][x] >= 0)
					m_pImageLayer->m_ImageOut.m_Blue[y][x] = InputB[y][x];
				else if (InputB[y][x] < 0)
					m_pImageLayer->m_ImageOut.m_Blue[y][x] = 0;
				else
					m_pImageLayer->m_ImageOut.m_Blue[y][x] = 255;
				
			}

		// 11. PSNR 값 수정 (input값과 Out값의 차이를 계산함)
		// GetPsnr(unsigned char **IR, unsigned char **IG, unsigned char **IB,  -> IN
		//			unsigned char **OR, unsigned char **OG, unsigned char **OB, 
		//			int nW, int nH)
		double Psnr_Value = GetPsnr(m_pImageLayer->m_Image.m_Red, m_pImageLayer->m_Image.m_Green, 
			m_pImageLayer->m_Image.m_Blue, m_pImageLayer->m_ImageOut.m_Red,
			m_pImageLayer->m_ImageOut.m_Green, m_pImageLayer->m_ImageOut.m_Blue, 
			m_pImageLayer->m_Image.m_nW, m_pImageLayer->m_Image.m_nH);

		std::cout << "PSNR : " << Psnr_Value << "\n";


		free_dmatrix(InputR, m_pImageLayer->m_Image.m_nH, m_pImageLayer->m_Image.m_nW);
		free_dmatrix(InputG, m_pImageLayer->m_Image.m_nH, m_pImageLayer->m_Image.m_nW);
		free_dmatrix(InputB, m_pImageLayer->m_Image.m_nH, m_pImageLayer->m_Image.m_nW);

		free_dmatrix(InputY, m_pImageLayer->m_Image.m_nH, m_pImageLayer->m_Image.m_nW);
		free_dmatrix(InputCb, m_pImageLayer->m_Image.m_nH / 2, m_pImageLayer->m_Image.m_nW / 2);
		free_dmatrix(InputCr, m_pImageLayer->m_Image.m_nH / 2, m_pImageLayer->m_Image.m_nW / 2);

		free_dmatrix(DCT_Y, m_pImageLayer->m_Image.m_nH, m_pImageLayer->m_Image.m_nW);
		free_dmatrix(DCT_Cb, m_pImageLayer->m_Image.m_nH / 2, m_pImageLayer->m_Image.m_nW / 2);
		free_dmatrix(DCT_Cr, m_pImageLayer->m_Image.m_nH / 2, m_pImageLayer->m_Image.m_nW / 2);

		free_dmatrix(Quan_Y, m_pImageLayer->m_Image.m_nH, m_pImageLayer->m_Image.m_nW);
		free_dmatrix(Quan_Cb, m_pImageLayer->m_Image.m_nH / 2, m_pImageLayer->m_Image.m_nW / 2);
		free_dmatrix(Quan_Cr, m_pImageLayer->m_Image.m_nH / 2, m_pImageLayer->m_Image.m_nW / 2);

		free_dmatrix(OutR, m_pImageLayer->m_Image.m_nH, m_pImageLayer->m_Image.m_nW);
		free_dmatrix(OutG, m_pImageLayer->m_Image.m_nH / 2, m_pImageLayer->m_Image.m_nW / 2);
		free_dmatrix(OutB, m_pImageLayer->m_Image.m_nH / 2, m_pImageLayer->m_Image.m_nW / 2);
	}

	bool escape = m_bKeyPressed['Q'];
	if (escape)
		exit(EXIT_SUCCESS);

	DrawSceneTextPos("Image Processing Z keyPress to Start", CKgPoint(10, 400));
	m_pImageLayer->DrawImage();
	m_pScene->Render();

	zip = false;
	CKhuGleWin::Update();
}

int main()
{
	char ExePath[MAX_PATH], ImagePath[MAX_PATH];

	GetModuleFileName(NULL, ExePath, MAX_PATH);

	int i;
	int LastBackSlash = -1;
	int nLen = strlen(ExePath);
	for(i = nLen-1 ; i >= 0 ; i--)
	{
		if(ExePath[i] == '\\') {
			LastBackSlash = i;
			break;
		}
	}

	if(LastBackSlash >= 0)
		ExePath[LastBackSlash] = '\0';

	std::cout << "Please write the name of the image to be processed.\n";
	std::cout << "After writing number or a name for your image, press z to start the process. Also press Q to quit.\n";
	std::cout << "EX)\n1.baboon.bmp\n2.bird.bmp\n3.camera.bmp\n4.couple.bmp\n5.girl.bmp\n6.house.bmp\n";
	
	std::string BMP_Name;
	std::cin >> BMP_Name; 
	
	if (BMP_Name == "1")
		BMP_Name = "baboon.bmp";
	else if (BMP_Name == "2")
		BMP_Name = "bird.bmp";
	else if (BMP_Name == "3")
		BMP_Name = "camera.bmp";
	else if (BMP_Name == "4")
		BMP_Name = "couple.bmp";
	else if (BMP_Name == "5")
		BMP_Name = "girl.bmp";
	else if (BMP_Name == "6")
		BMP_Name = "house.bmp";

	sprintf(ImagePath, "%s\\%s", ExePath, BMP_Name.c_str());

	CImageProcessing *pImageProcessing = new CImageProcessing(1280, 800, ImagePath);
	KhuGleWinInit(pImageProcessing);

	return 0;
}