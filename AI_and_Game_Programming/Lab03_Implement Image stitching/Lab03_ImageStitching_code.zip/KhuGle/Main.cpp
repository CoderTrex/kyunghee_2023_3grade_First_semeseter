//
//	Dept. Software Convergence, Kyung Hee University
//	Prof. Daeho Lee, nize@khu.ac.kr
//
#include "KhuGleWin.h"
#include <iostream>
#include <random>
#include <chrono>
#include "KhuGleSignal.h"

#pragma warning(disable:4996)

#define _CRTDBG_MAP_ALLOC
#include <cstdlib>
#include <crtdbg.h>

#ifdef _DEBUG
#ifndef DBG_NEW
#define DBG_NEW new ( _NORMAL_BLOCK , __FILE__ , __LINE__ )
#define new DBG_NEW
#endif
#endif  // _DEBUG

class CStitchingLayer : public CKhuGleLayer {
public:
	CKhuGleSignal m_LeftImage, m_RightImage, m_Image;

	CStitchingLayer(int nW, int nH, KgColor24 bgColor, CKgPoint ptPos = CKgPoint(0, 0))
		: CKhuGleLayer(nW, nH, bgColor, ptPos) {}
	
	void DrawBackgroundImage();
};

void CStitchingLayer::DrawBackgroundImage()
{
	for (int y = 0; y < m_nH; y++)
		for (int x = 0; x < m_nW; x++)
		{
			m_ImageBgR[y][x] = KgGetRed(m_bgColor);
			m_ImageBgG[y][x] = KgGetGreen(m_bgColor);
			m_ImageBgB[y][x] = KgGetBlue(m_bgColor);
		}

	if (m_LeftImage.m_Red && m_LeftImage.m_Green && m_LeftImage.m_Blue)
	{
		for (int y = 0; y < m_LeftImage.m_nH && y < m_nH; ++y)
			for (int x = 0; x < m_LeftImage.m_nW && x < m_nW; ++x)
			{
				m_ImageBgR[y][x] = m_LeftImage.m_Red[y][x];
				m_ImageBgG[y][x] = m_LeftImage.m_Green[y][x];
				m_ImageBgB[y][x] = m_LeftImage.m_Blue[y][x];
			}
	}

	if (m_RightImage.m_Red && m_RightImage.m_Green && m_RightImage.m_Blue)
	{
		int OffsetX = 600, OffsetY = 0;
		for (int y = 0; y < m_RightImage.m_nH && y + OffsetY < m_nH; ++y)
			for (int x = 0; x < m_RightImage.m_nW && x + OffsetX < m_nW; ++x)
			{
				m_ImageBgR[y + OffsetY][x + OffsetX] = m_RightImage.m_Red[y][x];
				m_ImageBgG[y + OffsetY][x + OffsetX] = m_RightImage.m_Green[y][x];
				m_ImageBgB[y + OffsetY][x + OffsetX] = m_RightImage.m_Blue[y][x];
			}
	}

	if (m_Image.m_Red && m_Image.m_Green && m_Image.m_Blue)
	{
		int OffsetX = 150, OffsetY = 250;
		for (int y = 0; y < m_Image.m_nH && y + OffsetY < m_nH; ++y)
			for (int x = 0; x < m_Image.m_nW && x + OffsetX < m_nW; ++x)
			{
				m_ImageBgR[y + OffsetY][x + OffsetX] = m_Image.m_Red[y][x];
				m_ImageBgG[y + OffsetY][x + OffsetX] = m_Image.m_Green[y][x];
				m_ImageBgB[y + OffsetY][x + OffsetX] = m_Image.m_Blue[y][x];
			}
	}
}

class CStitching : public CKhuGleWin {
public:
	CStitchingLayer *m_pStitchingLayer;

	CStitching(int nW, int nH, char* ImagePath1, char* ImagePath2);
	void Update();
};

CStitching::CStitching(int nW, int nH, char* ImagePath1, char* ImagePath2)
	: CKhuGleWin(nW, nH) {
	m_pScene = new CKhuGleScene(1040, 780, KG_COLOR_24_RGB(100, 100, 150));
	m_pStitchingLayer = new CStitchingLayer(900, 700, KG_COLOR_24_RGB(150, 150, 200), CKgPoint(70, 40));

	m_pStitchingLayer->m_LeftImage.ReadBmp(ImagePath1);
	m_pStitchingLayer->m_RightImage.ReadBmp(ImagePath2);
	m_pStitchingLayer->m_Image.m_nW = 600;
	m_pStitchingLayer->m_Image.m_nH = 400;

	m_pStitchingLayer->m_Image.m_Red = cmatrix(m_pStitchingLayer->m_Image.m_nH, m_pStitchingLayer->m_Image.m_nW);
	m_pStitchingLayer->m_Image.m_Green = cmatrix(m_pStitchingLayer->m_Image.m_nH, m_pStitchingLayer->m_Image.m_nW);
	m_pStitchingLayer->m_Image.m_Blue = cmatrix(m_pStitchingLayer->m_Image.m_nH, m_pStitchingLayer->m_Image.m_nW);

	for (int y = 0; y < m_pStitchingLayer->m_Image.m_nH; ++y)
		for (int x = 0; x < m_pStitchingLayer->m_Image.m_nW; ++x) {
			m_pStitchingLayer->m_Image.m_Red[y][x] = 0;
			m_pStitchingLayer->m_Image.m_Green[y][x] = 0;
			m_pStitchingLayer->m_Image.m_Blue[y][x] = 0;
		}
	m_pStitchingLayer->DrawBackgroundImage();
	
	m_pScene->AddChild(m_pStitchingLayer);
}

void CStitching::Update()
{
	if(m_bKeyPressed['S'])
	{
		srand(time(NULL));
		CKgPoint m_point1[10] = { {290,39}, {263,86}, {294,167}, {219, 68}, {263,117}, {228,96}, {197,95},{281,73},{199,146},{280,176} };
		CKgPoint m_point2[10] = { {102,47}, {77,89}, {101,172},  {30, 71},  {75,123}, {37,100}, {61,103},{118,99},{90,152}, {171,88} };

		double** InverseA = dmatrix(6, 6);
		double* y = new double[6];
		double* w = new double[6];
		double** table = dmatrix(6, 6);


		// diff�� ���ڰ� 6�� �̻��� �ƴϸ� �ٽ� ã��
		while (1)
		{

			int		rand_array[3];
			int		a, b, c;

			// 3���� ������ ���� ����
			for (;;) {
				a = rand()%10;
				b = rand()%10;
				c = rand()%10;
				if (a != b && b != c && a != c) break;
			}
			
			// �������� ������ m_point�� ��
			std::cout << "random number is : " << a << " " << b << " " << c << "\n";
			std::cout << "random point  is : " << m_point1[a].X << " " << m_point1[a].Y << "\n";
			std::cout << "random point  is : " << m_point1[b].X << " " << m_point1[b].Y << "\n";
			std::cout << "random point  is : " << m_point1[c].X << " " << m_point1[c].Y << "\n";
			rand_array[0] = a;
			rand_array[1] = b;
			rand_array[2] = c;

 
			// 6X6�迭�� 0~5���� m_point�� X, Y�� �ֱ�
			// 0
			table[0][0] = m_point1[rand_array[0]].X;
			table[0][1] = m_point1[rand_array[0]].Y;
			table[0][2] = 1;
			table[0][3] = 0;
			table[0][4] = 0;
			table[0][5] = 0;

			// 1
			table[1][0] = 0;
			table[1][1] = 0;
			table[1][2] = 0;
			table[1][3] = m_point1[rand_array[0]].X;
			table[1][4] = m_point1[rand_array[0]].Y;
			table[1][5] = 1;

			// 2
			table[2][0] = m_point1[rand_array[1]].X;
			table[2][1] = m_point1[rand_array[1]].Y;
			table[2][2] = 1;
			table[2][3] = 0;
			table[2][4] = 0;
			table[2][5] = 0;

			// 3
			table[3][0] = 0;
			table[3][1] = 0;
			table[3][2] = 0;
			table[3][3] = m_point1[rand_array[1]].X;
			table[3][4] = m_point1[rand_array[1]].Y;
			table[3][5] = 1;

			// 4
			table[4][0] = m_point1[rand_array[2]].X;
			table[4][1] = m_point1[rand_array[2]].Y;
			table[4][2] = 1;
			table[4][3] = 0;
			table[4][4] = 0;
			table[4][5] = 0;

			// 5
			table[5][0] = 0;
			table[5][1] = 0;
			table[5][2] = 0;
			table[5][3] = m_point1[rand_array[2]].X;
			table[5][4] = m_point1[rand_array[2]].Y;
			table[5][5] = 1;
			
			// Y�� �ֱ�		
			y[0] = m_point2[rand_array[0]].X;
			y[1] = m_point2[rand_array[0]].Y;
			y[2] = m_point2[rand_array[1]].X;
			y[3] = m_point2[rand_array[1]].Y;
			y[4] = m_point2[rand_array[2]].X;
			y[5] = m_point2[rand_array[2]].Y;

			// ���� ������ : W�� ��� �ϴ� �Լ�(KHU Library �� ������ �Լ�) 
			LeastSquared(table, w, y, 6, 6, false, 0);

			// �ζ��γ� ������ ���� ����
			int InLiner_count = 0;
			for (int i = 0; i < 10; i++)
			{
				// point1�� w�� ���ؼ� �̵���Ų sampleX, sampleY�� ���ڸ� ���� point2�� �񱳸� ����
				double sampleX = m_point1[i].X * w[0] + m_point1[i].Y * w[1] + 1 * w[2];
				double sampleY = m_point1[i].Y * w[3] + m_point2[i].Y * w[4] + 1 * w[5];

				// w �̵���Ų point1�� ���� point2�� ���� �Ÿ� ��
				double sampleX_abs = std::pow(std::abs(sampleX - m_point2[i].X), 2);
				double sampleY_abs = std::pow(std::abs(sampleY - m_point2[i].Y), 2);

				// �Ÿ��� �������� ����
				double diff = std::sqrt(sampleX_abs + sampleY_abs);
				
				// ���� ���� ���� 6���� ������ InLiner count�� ������
				if (diff < 10)
					InLiner_count++;
				std::cout << "diff result is : " << diff << "\n";
			}

			// ���� 6���� ������, while���� �ٽ� ���Ƽ� ������ �ݺ���.
			// InLiner count�� ������, matching�� ���� �ʱ� ������ �ݺ���
			if (InLiner_count >= 5)
			{
				std::cout << "InLiner count is : " << InLiner_count << "\n";
				break;
			}
		}

		// �̹����� ����
		CKgPoint OrgPos(0, 100);
		for (int y = 0; y < m_pStitchingLayer->m_Image.m_nH; ++y) {
			for (int x = 0; x < m_pStitchingLayer->m_Image.m_nW; ++x) {
				m_pStitchingLayer->m_Image.m_Red[y][x] = 0;
				m_pStitchingLayer->m_Image.m_Green[y][x] = 0;
				m_pStitchingLayer->m_Image.m_Blue[y][x] = 0;

				if (y - OrgPos.Y > 0 && y - OrgPos.Y < m_pStitchingLayer->m_LeftImage.m_nH &&
					x - OrgPos.X > 0 && x - OrgPos.X < m_pStitchingLayer->m_LeftImage.m_nW) {
					m_pStitchingLayer->m_Image.m_Red[y][x] = m_pStitchingLayer->m_LeftImage.m_Red[y - OrgPos.Y][x - OrgPos.X];
					m_pStitchingLayer->m_Image.m_Green[y][x] = m_pStitchingLayer->m_LeftImage.m_Green[y - OrgPos.Y][x - OrgPos.X];
					m_pStitchingLayer->m_Image.m_Blue[y][x] = m_pStitchingLayer->m_LeftImage.m_Blue[y - OrgPos.Y][x - OrgPos.X];
				}

				int newX = w[0] * (x - OrgPos.X) + w[1] * (y-OrgPos.Y) + w[2];
				int newY = w[3] * (x - OrgPos.X) + w[4] * (y-OrgPos.Y) + w[5];

				if (newY > 0 && newY < m_pStitchingLayer->m_RightImage.m_nH &&
					newX > 0 && newX < m_pStitchingLayer->m_RightImage.m_nW) {
					m_pStitchingLayer->m_Image.m_Red[y][x] = m_pStitchingLayer->m_RightImage.m_Red[newY][newX];
					m_pStitchingLayer->m_Image.m_Green[y][x] = m_pStitchingLayer->m_RightImage.m_Green[newY][newX];
					m_pStitchingLayer->m_Image.m_Blue[y][x] = m_pStitchingLayer->m_RightImage.m_Blue[newY][newX];
				}
			}
		}
		
		free_dmatrix(table, 6, 6);
		free_dmatrix(InverseA, 6, 6);
		delete[] y;
		delete[] w;

		m_bKeyPressed['S'] = false;
	}

	// ���� 2:
	if (m_bKeyPressed['D'])
	{
		srand(time(NULL));
		CKgPoint m_point1[10] = { {290,39}, {263,86}, {294,167}, {219, 68}, {263,117}, {228,96}, {197,95},{281,73},{199,146},{280,176} };
		CKgPoint m_point2[10] = { {102,47}, {77,89}, {101,172},  {30, 71},  {75,123}, {37,100}, {61,103},{118,99},{90,152}, {171,88} };

		double* y = new double[20];
		double* w = new double[6];
		double** table_10 = dmatrix(20, 6);
		double** InverseA_10 = dmatrix(20, 6);


		// 10��¥�� table�� ������.
		for (int i = 0; i < 20; i++)
		{
			if (i % 2 == 0)
			{
				// Y matrix ����
				y[i] = m_point2[i/2].X;
				// table matrix ����
				table_10[i][0] = m_point1[i/2].X;
				table_10[i][1] = m_point1[i/2].Y;
				table_10[i][2] = 1;
				table_10[i][3] = 0;
				table_10[i][4] = 0;
				table_10[i][5] = 0;
			}
			else
			{
				// Y matrix ����
				y[i] = m_point2[i/2].Y;
				// table matrix ����
				table_10[i][0] = 0;
				table_10[i][1] = 0;
				table_10[i][2] = 0;
				table_10[i][3] = m_point1[i/2].X;
				table_10[i][4] = m_point1[i/2].Y;
				table_10[i][5] = 1;
			}
		}

		std::cout << "10 number table matrix" << "\n";
		for (int i = 0; i < 20; i++)
		{
			for (int j = 0; j < 6; j++)
				std::cout << table_10[i][j] << " ";
			std::cout << "\n";
		}

		std::cout << "\n10 number Y matrix" << "\n";
		for (int i = 0; i < 20; i++)
			std::cout << y[i] << " ";


		// ���� ������ ���
		LeastSquared(table_10, w, y, 20, 6, false, 0);

		std::cout << "\n10 number W matrix : " << "\n";
		for (int i = 0; i < 6; i++)
			std::cout << w[i] << " ";
		std::cout << "\n";


		// �ռ� �����ߴ� Random3d�� ����� ������ ������ 10���� ����
		int InLiner_count = 0;
		for (int i = 0; i < 10; i++)
		{
			double sampleX = m_point1[i].X * w[0] + m_point1[i].Y * w[1] + 1 * w[2];
			double sampleY = m_point1[i].Y * w[3] + m_point2[i].Y * w[4] + 1 * w[5];

			double sampleX_abs = std::pow(std::abs(sampleX - m_point2[i].X), 2);
			double sampleY_abs = std::pow(std::abs(sampleY - m_point2[i].Y), 2);

			double diff = std::sqrt(sampleX_abs + sampleY_abs);
			if (diff < 10)
				InLiner_count++;
			std::cout << "10 number diff result is : " << diff << "\n";
		}

		// diff�� 6���� ���� ���� (InLiner Count)
		std::cout << "10 number InLiner count is : " << InLiner_count << "\n";

		CKgPoint OrgPos(0, 100);
		for (int y = 0; y < m_pStitchingLayer->m_Image.m_nH; ++y) {
			for (int x = 0; x < m_pStitchingLayer->m_Image.m_nW; ++x) {
				m_pStitchingLayer->m_Image.m_Red[y][x] = 0;
				m_pStitchingLayer->m_Image.m_Green[y][x] = 0;
				m_pStitchingLayer->m_Image.m_Blue[y][x] = 0;
				if (y - OrgPos.Y > 0 && y - OrgPos.Y < m_pStitchingLayer->m_LeftImage.m_nH &&
					x - OrgPos.X > 0 && x - OrgPos.X < m_pStitchingLayer->m_LeftImage.m_nW) {
					m_pStitchingLayer->m_Image.m_Red[y][x] = m_pStitchingLayer->m_LeftImage.m_Red[y - OrgPos.Y][x - OrgPos.X];
					m_pStitchingLayer->m_Image.m_Green[y][x] = m_pStitchingLayer->m_LeftImage.m_Green[y - OrgPos.Y][x - OrgPos.X];
					m_pStitchingLayer->m_Image.m_Blue[y][x] = m_pStitchingLayer->m_LeftImage.m_Blue[y - OrgPos.Y][x - OrgPos.X];
				}
				int newX = w[0] * (x - OrgPos.X) + w[1] * (y - OrgPos.Y) + w[2];
				int newY = w[3] * (x - OrgPos.X) + w[4] * (y - OrgPos.Y) + w[5];
				if (newY > 0 && newY < m_pStitchingLayer->m_RightImage.m_nH &&
					newX > 0 && newX < m_pStitchingLayer->m_RightImage.m_nW) {
					m_pStitchingLayer->m_Image.m_Red[y][x] = m_pStitchingLayer->m_RightImage.m_Red[newY][newX];
					m_pStitchingLayer->m_Image.m_Green[y][x] = m_pStitchingLayer->m_RightImage.m_Green[newY][newX];
					m_pStitchingLayer->m_Image.m_Blue[y][x] = m_pStitchingLayer->m_RightImage.m_Blue[newY][newX];
				}
			}
		}
		free_dmatrix(table_10, 20, 6);
		free_dmatrix(InverseA_10, 20, 6);
		delete[] y;
		delete[] w;

		m_bKeyPressed['D'] = false;
	}
	
	m_pStitchingLayer->DrawBackgroundImage();
	m_pScene->Render();
	DrawSceneTextPos("Stitching Lab03        PRESS S: Random 3 number        PRESS D: Use All 10 number", CKgPoint(0, 0));
	
	CKhuGleWin::Update();
}

int main()
{
	char ExePath[MAX_PATH], ImagePath1[MAX_PATH], ImagePath2[MAX_PATH];

	GetModuleFileName(NULL, ExePath, MAX_PATH);

	int i;
	int LastBackSlash = -1;
	int nLen = strlen(ExePath);
	for (i = nLen - 1; i >= 0; i--)
	{
		if (ExePath[i] == '\\') {
			LastBackSlash = i;
			break;
		}
	}

	if (LastBackSlash >= 0)
		ExePath[LastBackSlash] = '\0';

	sprintf(ImagePath1, "%s\\%s", ExePath, "panorama_image1.bmp");
	sprintf(ImagePath2, "%s\\%s", ExePath, "panorama_image2.bmp");

	CStitching* pStitching = new CStitching(1040, 780, ImagePath1, ImagePath2);


	KhuGleWinInit(pStitching);

	return 0;
}